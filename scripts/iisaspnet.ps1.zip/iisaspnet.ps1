Configuration IISASPNET
{
  Import-DSCResource -ModuleName PSDesiredStateConfiguration
  Import-DSCResource -ModuleName xNetworking -Name xFirewall

  Node localhost
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

    WindowsFeature WebServerManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }

    #Enable ICMP in and out through Firewall
    xFirewall EnableV4PingIn
    {
      Name = "FPS-ICMP4-ERQ-In"
      Enabled = "True"
    }
    
    xFirewall EnableV4PingOut
    {
      Name = "FPS-ICMP4-ERQ-Out"
      Enabled = "True"
    }
  }
}