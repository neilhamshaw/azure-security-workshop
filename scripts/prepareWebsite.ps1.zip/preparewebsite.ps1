Configuration PrepareWebsite
{
    Param ( [string] $nodeName )

    Import-DSCResource -ModuleName PSDesiredStateConfiguration
    Import-DSCResource -ModuleName xNetworking -Name xFirewall
    Import-DSCResource -ModuleName BitsTransfer
    Import-DSCResource -ModuleName xWebAdministration

    Node $nodeName
    {
        #Install the IIS Role
        WindowsFeature IIS {
            Name   = "Web-Server"
            Ensure = "Present"
        }

        #Install ASP.NET 4.5
        WindowsFeature ASP {
            Name      = "Web-Asp-Net45"
            Ensure    = "Present"
        }

        WindowsFeature WebServerManagementConsole {
            Name   = "Web-Mgmt-Console"
            Ensure = "Present"
        }

        #Enable ICMP in and out through Firewall
        xFirewall EnableV4PingIn
        {
            Name    = "FPS-ICMP4-ERQ-In"
            Enabled = "True"
        }
    
        xFirewall EnableV4PingOut
        {
            Name    = "FPS-ICMP4-ERQ-Out"
            Enabled = "True"
        }

        Script DotNetCore
        {
            GetScript = 
            {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = ('True' -in (Test-Path "C:\Setup\dotnet-hosting-2.2.5-win.exe"))
                }
            }

            SetScript = 
            {
                #Create Setup Directory if it does not exist
                if (-not (Test-Path "C:\Setup" -PathType Container)) {
                    mkdir "C:\Setup"    
                }
                $url = "https://raw.githubusercontent.com/neilhamshaw/azure-security-workshop/master/scripts/dotnet-hosting-2.2.5-win.exe"
                $output = "C:\Setup\dotnet-hosting-2.2.5-win.exe"
                Start-BitsTransfer -Source $url -Destination $output
            }

            TestScript = {
                Test-Path "C:\Setup\dotnet-hosting-2.2.5-win.exe"
            }
        }

        Package InstallDotNetCore
        {
            Ensure    = "Present"
            Path      = "C:\Setup\dotnet-hosting-2.2.5-win.exe"
            Arguments = "/q /norestart"
            Name      = "DotNetCore"
            ProductId = "F3E70651-6997-33C1-BB20-B7291E136BDF"
            DependsOn = "[Script]DotNetCore"
        }

        xWebsite DefaultSite {
            Ensure       = "Present"
            Name         = "Default Web Site"
            State        = "Stopped"
            PhysicalPath = "C:\inetpub\wwwroot"
            DependsOn    = "[WindowsFeature]IIS"
        }

        xWebAppPool LabWebsiteAppPool {
            Ensure                = "Present"
            Name                  = "lab-app"
            State                 = "Started"
            managedRuntimeVersion = ""
        }

        xWebsite LabWebsite {
            Ensure          = "Present"
            Name            = "Lab Website"
            State           = "Started"
            PhysicalPath    = "C:\inetpub\LabWebsite"
            ApplicationPool = "lab-app"
            BindingInfo = MSFT_xWebBindingInformation {
                Port      = "80"
                IPAddress = "*"
                Protocol  = "HTTP"
            }
            DependsOn = "[xWebAppPool]LabWebsiteAppPool"
        }
    }
}

PrepareWebsite -nodeName localhost