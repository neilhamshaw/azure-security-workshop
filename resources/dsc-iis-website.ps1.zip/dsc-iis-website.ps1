Configuration IIS-WebServerConfig
{
    param (
        [string[]] $ComputerName = $env:ComputerName
    )

    Import-DSCResource -ModuleName PSDesiredStateConfiguration
    Import-DSCResource -ModuleName xNetworking -Name xFirewall
    Import-DSCResource -ModuleName BitsTransfer
    Import-DSCResource -ModuleName xWebAdministration -ModuleVersion 2.6.0.0

    Node localhost
    {
        #Install the IIS Role
        WindowsFeature IIS {
            Name   = "Web-Server"
            Ensure = "Present"
        }

        #Delete the default website
        xWebsite DeleteDefaultSite {
            Ensure       = "Absent"
            Name         = "Default Web Site"
            State        = "Stopped"
            PhysicalPath = "C:\inetpub\wwwroot"
            DependsOn    = "[WindowsFeature]IIS"
        }

        #Install IIS Management Console
        WindowsFeature WebServerManagementConsole {
            Name   = "Web-Mgmt-Console"
            Ensure = "Present"
        }

        #Create new App Pool for the .NET Website
        xWebAppPool CreatNewDotNetAppPool {
            Ensure                = "Present"
            Name                  = "DotNetAppPool"
            State                 = "Started"
            managedRuntimeVersion = ""
        }

        Script CreateNewWebHomeDirectory
        {
            GetScript = 
            {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = ('True' -in (Test-Path "C:\inetpub\ProductionRoot"))
                }
            }

            SetScript = 
            {
                #Create Website Directory if it does not exist
                if (-not (Test-Path "C:\inetpub\ProductionRoot" -PathType Container)) {
                    mkdir "C:\inetpub\ProductionRoot"    
                }
            }

            TestScript = {
                Test-Path "C:\inetpub\ProductionRoot"
            }
        }

        #Copy Website Files to target directory
        File DirectoryWebFiles {
            Ensure          = "Present"
            Type            = "Directory"
            Recurse         = $true
            SourcePath      = "$PSscriptroot\DemoAPIWebFiles"
            DestinationPath = "C:\inetpub\ProductionRoot"
        }

        #Create the new web site in IIS
        xWebsite CreateNewWebsite {
            Ensure          = "Present"
            Name            = "ProductionWebsite"
            State           = "Started"
            PhysicalPath    = "C:\inetpub\ProductionRoot"
            ApplicationPool = "DotNetAppPool"
            BindingInfo = MSFT_xWebBindingInformation {
                Port      = "80"
                IPAddress = "*"
                Protocol  = "HTTP"
            }
            DependsOn = "[xWebAppPool]CreatNewDotNetAppPool"
        }

        #Set Environment Variable to the relevant property
        xWebConfigPropertyCollection "$($ComputerName) - Set Application Environment"
        {
            WebsitePath = "MACHINE/WEBROOT/APPHOST/ProductionWebsite"
            Filter = "system.webServer/aspNetCore"
            CollectionName = "environmentVariables"
            ItemName = "environmentVariable"
            ItemKeyName = "name"
            ItemKeyValue = "ASPNETCORE_ENVIRONMENT"
            ItemPropertyName = "value"
            ItemPropertyValue = "Production.A"
            Ensure = "Present"
        }
        

        #Enable ICMP in and out through Firewall
        xFirewall EnableICMPv4-PingIn
        {
            Name    = "FPS-ICMP4-ERQ-In"
            Enabled = "True"
        }
    
        xFirewall EnableICMPv4-PingOut
        {
            Name    = "FPS-ICMP4-ERQ-Out"
            Enabled = "True"
        }

        #Download .NET Core
        Script GetDotNetCore
        {
            GetScript = 
            {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = ('True' -in (Test-Path "C:\Setup\dotnet-hosting-2.2.5-win.exe"))
                }
            }

            SetScript = 
            {
                #Create Setup Directory if it does not exist
                if (-not (Test-Path "C:\Setup" -PathType Container)) {
                    mkdir "C:\Setup"    
                }

                #Download the .NET Core executable file
                $url = "https://raw.githubusercontent.com/neilhamshaw/azure-security-workshop/master/resources/dotnet-hosting-2.2.5-win.exe"
                $output = "C:\Setup\dotnet-hosting-2.2.5-win.exe"
                Start-BitsTransfer -Source $url -Destination $output
            }

            TestScript = {
                Test-Path "C:\Setup\dotnet-hosting-2.2.5-win.exe"
            }
        }

        #Install the .NET Core package
        Package InstallDotNetCore
        {
            Ensure    = "Present"
            Path      = "C:\Setup\dotnet-hosting-2.2.5-win.exe"
            Arguments = "/q /norestart"
            Name      = "DotNetCore"
            ProductId = "F3E70651-6997-33C1-BB20-B7291E136BDF"
            DependsOn = "[Script]GetDotNetCore"
        }
    }
}